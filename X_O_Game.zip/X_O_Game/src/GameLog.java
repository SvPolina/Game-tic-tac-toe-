import java.util.Random;
import java.security.SecureRandom;

import javax.swing.JOptionPane;

public class GameLog {
	
public final static int empty=0, X=1, O=2, Bsize=3;	

private int[][] board=new int[Bsize][Bsize];
public   int cnt=0;
private  int Csign;
private  int Psign;

//board initialization
public  GameLog(){
	clear();
	             }

public void clear(){
	for(int i=0;i<3;i++){
        for(int j=0;j<3;j++){
        this.board[i][j]=0;    
         }}	
}

//The player chooses the sign he wants to play with
public void setSign(int m){
	if (m==1){ this.Psign=X; this.Csign=O; }
	if (m==2){ this.Psign=O; this.Csign=X; } 
}


//Checks if the cell is empty
public boolean isEmpty(int i, int j){
	if(board[i][j]==empty){return true; }
	else                  {return false;}
}

//the player chooses row and column to place his sign
//if the cell is not empty the system will announce about it
//and will give another option to place the sign
public void PlayerMat(int i, int j, int sign) throws ArrayIndexOutOfBoundsException{
	 if  (board[i][j]==empty) 
	     {board[i][j]=sign;cnt++;}	
}

public int[][] getBoard(){	
return board;	         }

//Random decision whether player or computer starts the game

public int start(){
	SecureRandom randomNumbers = new SecureRandom();
	int num=randomNumbers.nextInt(2);
	return num;
}

//Game logic
public boolean ComputerSign(){
		 if (win())           {return true;}
	else if (Block())         {cnt++;return false;}
	else if (Try())           {cnt++;return false;}	
	else if (Center())        {cnt++;return false;}
	else if (OppositeCorner()){cnt++;return false;}
	else if (EmptyCorner())   {cnt++;return false;}
	else if (EmptySide())     {cnt++; return false;}	
	else                      {def(); cnt++; return false;  }
							}

public boolean def(){
	if(cnt>6&&cnt<9){
		for(int i=0;i<Bsize;i++){
		    for(int j=0;j<Bsize;j++){
		    	if( board[i][j]==empty){
		    		board[i][j]=Csign;
		    		break;
		    							}
		    						}break;
					}
		
	}
	return false;}

public boolean win(){
	
		for(int i=0;i<Bsize;i++){
	    for(int j=0;j<Bsize;j++){    	   
	    	   	    	if (j==0&&board[i][j]==Csign&&board[i][j+1]==Csign&&board[i][j+2]==empty){board[i][j+2]=Csign;	  return true;  }
		    	  else  if (j==0&&board[i][j]==empty&&board[i][j+1]==Csign&&board[i][j+2]==Csign){board[i][j]=Csign; 	  return true;  }
		    	  else  if (j==0&&board[i][j]==Csign&&board[i][j+1]==empty&&board[i][j+2]==Csign){board[i][j+1]=Csign;	  return true;  }
		    	  
		    	  else  if (i==0&&board[i][j]==Csign&&board[i+1][j]==Csign&&board[i+2][j]==empty){board[i+2][j]=Csign;    return true;  }
		    	  else  if (i==0&&board[i][j]==empty&&board[i+1][j]==Csign&&board[i+2][j]==Csign){board[i][j]=Csign;      return true;	}
		    	  else  if (i==0&&board[i][j]==Csign&&board[i+1][j]==empty&&board[i+2][j]==Csign){board[i+1][j]=Csign;    return true;  } 
		    	  
		    	  else  if (board[0][0]==Csign&&board[1][1]==Csign&&board[2][2]==empty){board[2][2]=Csign; return true;   } 
		    	  else  if (board[0][0]==Csign&&board[1][1]==empty&&board[2][2]==Csign){board[1][1]=Csign; return true;   }
		    	  else  if (board[0][0]==empty&&board[1][1]==Csign&&board[2][2]==Csign){board[0][0]=Csign; return true;   }
		    	  
		    	  else  if (board[0][2]==Csign&&board[1][1]==Csign&&board[2][0]==empty){board[2][0]=Csign; return true;   } 
		    	  else  if (board[0][2]==Csign&&board[1][1]==empty&&board[2][0]==Csign){board[1][1]=Csign; return true;   }
		    	  else  if (board[0][2]==empty&&board[1][1]==Csign&&board[2][0]==Csign){board[0][2]=Csign; return true;   }	   
	    						}}	       
	return false;
}


private boolean Block(){
				for(int i=0;i<Bsize;i++){
				for(int j=0;j<Bsize;j++){	  
					
					 if (board[i][j] == Psign && board[i][(j+1)%3] == Psign && board[i][(j+2)%3] == empty) {
		                    board[i][(j+2)%3] = Csign;
		                    return true;		                                                           }
					 
					 if (board[j][i] == Psign && board[(j+1)%3][i] == Psign && board[(j+2)%3][i] == empty) {
		                    board[(j+2)%3][i] = Csign;
		                    return true;		                                                           }
					  
				
	    	  		
		    	  else  if (board[0][0]==Psign&&board[1][1]==Psign&&board[2][2]==empty){board[2][2]=Csign; 					return true;  } 
		    	  else  if (board[0][0]==Psign&&board[1][1]==empty&&board[2][2]==Psign){board[1][1]=Csign; 					return true;  }
		    	  else  if (board[0][0]==empty&&board[1][1]==Psign&&board[2][2]==Psign){board[0][0]=Csign; 					return true;  }
		    	  
		    	  else  if (board[0][2]==Psign&&board[1][1]==Psign&&board[2][0]==empty){board[2][0]=Csign; 					return true;  } 
		    	  else  if (board[0][2]==Psign&&board[1][1]==empty&&board[2][0]==Psign){board[1][1]=Csign; 					return true;  }
		    	  else  if (board[0][2]==empty&&board[1][1]==Psign&&board[2][0]==Psign){board[0][2]=Csign; 					return true;  }	    
										}} 
	       	return false;
}

private boolean Center(){
	if (board[1][1]==empty){board[1][1]=Csign; return true;}	
	else return false;}

private boolean OppositeCorner(){
	if(board[0][0]==Psign&&board[2][2]==empty){board[2][2]=Csign;return true; }
	if(board[2][2]==Psign&&board[0][0]==empty){board[0][0]=Csign;return true; }
	if(board[0][2]==Psign&&board[2][0]==empty){board[2][0]=Csign;return true; }
	if(board[2][0]==Psign&&board[0][2]==empty){board[0][2]=Csign;return true; }	
	else return false;               }

private boolean EmptyCorner(){
		for(int i=0;i<3;i+=2)         {
        for (int j = 0; j < 3; j += 2){
        if(board[i][j]==empty)  {board[i][j]=Csign;return true;}
        							  }}	
	    return false;        }


private boolean EmptySide(){		
        for (int j = 0; j < 3; j += 2){        	
         if (board[0][j]==empty&&board[1][j]==empty&&board[2][j]==empty){Random randomNumbers = new Random();int num=randomNumbers.nextInt(3); board[num][j]=Csign; return true;}      
        }        
        for (int i = 0; i < 3; i += 2){  
		if  (board[i][0]==empty&&board[i][1]==empty&&board[i][2]==empty){Random randomNumbers = new Random();int num=randomNumbers.nextInt(3); board[i][num]=Csign; return true;}
                                      }
        return false;
}


private boolean Try(){
//if one of the corners
	if      (board[0][0]==Psign&&board[0][1]==empty&&board[0][2]==empty){Random randomNumbers = new Random();int num=randomNumbers.nextInt(2); board[0][num+1]=Csign;return true;}
	else if (board[0][0]==empty&&board[0][1]==empty&&board[0][2]==Psign){Random randomNumbers = new Random();int num=randomNumbers.nextInt(2); board[num][0]=Csign;  return true;}
	else if (board[2][0]==Psign&&board[2][1]==empty&&board[2][2]==empty){Random randomNumbers = new Random();int num=randomNumbers.nextInt(2); board[2][num+1]=Csign;return true;}
	else if (board[2][0]==empty&&board[2][1]==empty&&board[2][2]==Psign){Random randomNumbers = new Random();int num=randomNumbers.nextInt(2); board[num][2]=Csign;  return true;}
			
	else return false;	
}

//Checks if the player won

public boolean chekWin(){
		
    if(board[0][0]==Psign&&board[0][1]==Psign&&board[0][2]==Psign){return true;}	
	
	if(board[1][0]==Psign&&board[1][1]==Psign&&board[1][2]==Psign){return true;}
	
	if(board[2][0]==Psign&&board[2][1]==Psign&&board[2][2]==Psign){return true;}	

	if(board[0][0]==Psign&&board[1][0]==Psign&&board[2][0]==Psign){return true;}	
	
	if(board[0][1]==Psign&&board[1][1]==Psign&&board[2][1]==Psign){return true;}		
	
	if(board[2][0]==Psign&&board[2][1]==Psign&&board[2][2]==Psign){return true;}	
	
	if(board[0][0]==Psign&&board[1][1]==Psign&&board[2][2]==Psign){return true;}	
	
	if(board[0][2]==Psign&&board[1][1]==Psign&&board[2][0]==Psign){return true;}	
	else return false;
}

}

import javax.swing.*;


public class PlayGame {
	
static String  textX,textY;	
static int x,y,res;	

	public static void main (String[] args){
				
		 boolean play=true; 
		 boolean continue_loop=false;		
		 boolean continue_loop1=false;		

		 while(play){	
			
			JFrame application=new JFrame();		
			application.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
			application.setVisible(true);
			application.setSize(400,400);
			GameLog myGame=new GameLog();
			Panel myPanel= new Panel(myGame);			
			application.add(myPanel);
		
//the player chooses sign and the computer randomly decides who is going to start the game		
	
			String message= JOptionPane.showInputDialog("Please choose\n 1 if your sign is  X\n 2 if your sign is O");		
			int in=Integer.parseInt(message);		
			myGame.setSign(in);
				if (myGame.start()==0)
					{
					JOptionPane.showMessageDialog(null,"The computer starts\n");
					myGame.ComputerSign();application.repaint();
					}
//the game continues until one of the player wins or until the board is full, 
//the computer asks if the player wants to play again
				
				while(myGame.cnt!=9)	
					{					
//receive input values and check they are valid					
						do{	
							do{	
								try {
									
									
									do{	
										try {	
											continue_loop=false;
											JTextField xField=new JTextField(5);
											JTextField yField=new JTextField(5);		
											JPanel pan=new JPanel();
											pan.add(new JLabel("Row:"));
											pan.add(xField);
											pan.add(Box.createHorizontalStrut(15));
											pan.add(new JLabel("Col:"));
											pan.add(yField);		
											int result=JOptionPane.showConfirmDialog(null,pan,"Please enter row and col values",JOptionPane.OK_CANCEL_OPTION);
											if (result==JOptionPane.OK_OPTION){	}	
											textX = xField.getText();
											textY = yField.getText();  						
											x=input_val(textX);
											y=input_val(textY);				    	
											}							
										catch(NumberFormatException numberFormatException)
											{
											JOptionPane.showMessageDialog(null, "The row/column values should be integers between 0 & 2");
											continue_loop=true;	 
											}
										}while (continue_loop); 				
					
								continue_loop1=false;				    	
				    	        if(myGame.isEmpty(x,y)==false) {JOptionPane.showMessageDialog(null,"This place is taken\n please try again");}					    	        
									}
								catch(ArrayIndexOutOfBoundsException arrayIndexOutOfBoundsException)
									{
									JOptionPane.showMessageDialog(null, "The row and column values should be between 0 & 2");
									continue_loop1=true;
									}
								}while (continue_loop1); 
							}while(!myGame.isEmpty(x,y));	
					
					myGame.PlayerMat(x,y,in);							
					application.repaint();
				
//if the player won					
					if ( myGame.chekWin()==true)  
					{
				application.repaint(); JOptionPane.showMessageDialog(null,"Great, you won!");							
				res = JOptionPane.showConfirmDialog(null,"Would you like to play again?",null, JOptionPane.YES_NO_OPTION);
					if (res==JOptionPane.YES_OPTION){myGame.cnt=0;  }  
						else {play=false;application.setVisible(false);}
					break;	
					}	
					
//if the computer won	    
						else if(myGame.ComputerSign()==true)
							{
							application.repaint();	JOptionPane.showMessageDialog(null,"Too bad, \n the computer won :("); 						
							res = JOptionPane.showConfirmDialog(null,"Would you like to play again?",null, JOptionPane.YES_NO_OPTION);
								if (res==JOptionPane.YES_OPTION){myGame.cnt=0; }  
								else {play=false;application.setVisible(false);}
								break;
							}		
							else {
								application.repaint();
									}									
	
//if the board is full	
						if(myGame.cnt>9)
						{ 
							res = JOptionPane.showConfirmDialog(null,"It's a tie, \n Would you like to play again?",null, JOptionPane.YES_NO_OPTION);
							if (res==JOptionPane.YES_OPTION){myGame.cnt=0; }							
							else {play=false;application.setVisible(false);} 
							break;
						} 			
					
						}  				
					}
				}
		
			
public static int input_val(String s)throws  NumberFormatException
{int x=Integer.parseInt(s);
 return x;}

				}

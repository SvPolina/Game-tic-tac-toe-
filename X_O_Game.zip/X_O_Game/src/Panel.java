import java.awt.Color;
import java.awt.Graphics;
import javax.swing.JPanel;

public class Panel extends JPanel{
	
private myLine[] lines=new myLine[4];
private GameLog game;

public Panel(GameLog game){
	this.game=game;	
}
 

public void paintComponent (Graphics g){
	int h=getHeight();
	int w=getHeight();
	int k;
	int count=0;

	
	for (k=1; k<3; k++){
		int x1=w/3*k;
		int y1=0;
		int x2=w/3*k;
		int y2=h;
		
		Color color= new Color(77,67,123);
		lines[count]=new myLine(x1,y1,x2,y2,color);
		count++;
	}
	
	for (k=1; k<3; k++){
		int x1=0;
		int y1=h/3*k;
		int x2=w;
		int y2=h/3*k;
		
		Color color= new Color(77,15,123);
		lines[count]=new myLine(x1,y1,x2,y2,color);
		count++;
	}	
				
super.paintComponent(g);
for(myLine line: lines){
	line.draw(g);
	for(int i=0;i<3;i++){
       for(int j=0;j<3;j++){	
	if (game.getBoard()[i][j]==2){
	g.drawOval(h/6+h/3*(j)-25, w/6+w/3*(i)-25, 50, 50);}
	
	if (game.getBoard()[i][j]==1){
	g.drawLine(h/6+h/3*(j)-20, w/6+w/3*(i)-20, h/6+h/3*(j)+20, w/6+w/3*(i)+20);
	g.drawLine(h/6+h/3*(j)-20, w/6+w/3*(i)+20, h/6+h/3*(j)+20, w/6+w/3*(i)-20);	}
      }
      }
	
}
}
}

